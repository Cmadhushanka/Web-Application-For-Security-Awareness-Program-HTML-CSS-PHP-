<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $entered_otp = $_POST["otp"];

    // Check if OTP matches the one sent to the user
    if ($entered_otp == $_SESSION['otp']) {
        $employeeid = $_SESSION['employeeid'];
        $position = $_SESSION['position']; 

        $_SESSION['loggedin'] = true;

        // Check the role and redirect accordingly
        if ($position == 'Admin') {
            echo "<script>
                alert('Admin login successful!');
                window.location.href = 'admin_profile.php';
            </script>";
        } else {
            echo "<script>
                alert('User login successful!');
                window.location.href = 'profile.php';
            </script>";
        }

    } else {
        echo "<script>alert('Invalid OTP. Please try again.');</script>";
    }
}
?>
