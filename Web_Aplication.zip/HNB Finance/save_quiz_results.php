<?php
session_start();

// Check if the session has an employeeid
if (isset($_SESSION['employeeid']) && isset($_POST['score']) && isset($_POST['status'])) {
    $employeeid = $_SESSION['employeeid']; // Get employee ID from session
    $firstAttemptScore = $_POST['score'];
    $firstAttemptStatus = $_POST['status'];

    // Database connection
    include 'connect.php';  // Include your DB connection file

    // First, check if a record exists for this employeeid
    $sql = "SELECT * FROM marks WHERE employeeid = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $employeeid);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // Record exists, so update it
        $sql = "UPDATE marks SET first_attempt_score = ?, first_attempt_status = ? WHERE employeeid = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("isi", $firstAttemptScore, $firstAttemptStatus, $employeeid);
    } else {
        // Record does not exist, so insert a new one
        $sql = "INSERT INTO marks (employeeid, first_attempt_score, first_attempt_status) VALUES (?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("iis", $employeeid, $firstAttemptScore, $firstAttemptStatus);
    }

    // Execute the query (either insert or update)
    if ($stmt->execute()) {
        echo "Quiz results saved successfully.";
    } else {
        echo "Error: " . $stmt->error;
    }

    // Close statement and connection
    $stmt->close();
    $conn->close();
} else {
    echo "Invalid request or session expired.";
}
?>
