<?php
session_start(); // Start session

// Check if the user is logged in by checking if 'employeeid' exists in the session
if (isset($_SESSION['employeeid'])) {
    $employeeid = $_SESSION['employeeid'];

    include 'connect.php'; // Database connection file

    // Fetch user data from the 'users' table
    $sql = "SELECT employeeid, username, position, email FROM users WHERE employeeid = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $employeeid);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $userData = $result->fetch_assoc();
        // Store user data in variables for the HTML page
        $username = $userData['username'];
        $email = $userData['email'];
        $position = $userData['position'];
    } else {
        echo "No user data found.";
        exit(); // Stop further execution
    }

    // Initialize quiz data variables with default values
    $firstAttemptScore = "N/A";
    $firstAttemptStatus = "No quiz attempt yet";
    $lastAttemptScore = "N/A";
    $lastAttemptStatus = "No quiz attempt yet";

    // Fetch quiz data from the 'marks' table
    $sql = "SELECT first_attempt_score, first_attempt_status, last_attempt_score, last_attempt_status FROM marks WHERE employeeid = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $employeeid);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $quizData = $result->fetch_assoc();
        $firstAttemptScore = $quizData['first_attempt_score'];
        $firstAttemptStatus = $quizData['first_attempt_status'];
        $lastAttemptScore = $quizData['last_attempt_score'];
        $lastAttemptStatus = $quizData['last_attempt_status'];
    } else {
         $firstAttemptScore = "N/A";
         $firstAttemptStatus = "No quiz attempt yet";
         $lastAttemptScore = "N/A";
         $lastAttemptStatus = "No quiz attempt yet";
    }

    // Get beginner progress from the session
    $beginnerProgress = isset($_SESSION['beginnerProgress']) ? $_SESSION['beginnerProgress'] : 0;

    $stmt->close();
    $conn->close();
} else {
    // If the user is not logged in, redirect to the login page
    header("Location: login2.php");
    exit();
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>User Profile</title>
  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <!-- Custom Styles -->
  <link rel="stylesheet" href="css/style.css">
  <!-- Responsive -->
  <link rel="stylesheet" href="css/responsive.css">
  <!-- Favicon -->
  <link rel="icon" href="images/fevicon.png" type="image/gif" />
  <!-- Scrollbar Custom CSS -->
  <link rel="stylesheet" href="css/jquery.mCustomScrollbar.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css">
  <!-- Fancybox -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.css" media="screen">
  <style>
    body {
      font-family: Arial, sans-serif;
      background-color: #f4f4f4;
      margin: 0;
      padding: 0;
    }
    .profile-container {
      width: 1000px;
      height: 100vh;
      margin: 50px auto;
      padding: 40px;
      background-color: white;
      box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
      border-radius: 15px; 
    }
    .profile-header {
      display: flex;
      align-items: center;
      justify-content: center;
      margin-bottom: 20px;
    }
    .profile-picture {
      border-radius: 50%;
      width: 120px;
      height: 120px;
      object-fit: cover;
      border: 2px solid #ddd;
    }
    .profile-info {
      margin-left: 20px;
    }
    .profile-info h2 {
      margin: 0;
      font-size: 24px;
    }
    .profile-info p {
      margin: 5px 0;
      color: #666;
    }
    .profile-section {
      margin-bottom: 20px;
    }
    .profile-section h3 {
      border-bottom: 2px solid #007BFF;
      padding-bottom: 5px;
      margin-bottom: 10px;
    }
    .quiz-progress {
      background-color: #ddd;
      height: 25px;
      width: 100%;
      border-radius: 5px;
      overflow: hidden;
      margin-bottom: 10px;
    }
    .quiz-progress-bar {
      height: 100%;
      width: 70%;
      background-color: #28a745;
      text-align: center;
      color: white;
      line-height: 25px;
    }
    .quiz-section {
      display: flex; /* Use flexbox layout */
      justify-content: center; /* Center horizontally */
      align-items: center; /* Center vertically (if needed) */
      height: 100vh; /* Example height, adjust as needed */
    }

    .start-quiz {
      background-color: #007BFF; /* Blue background */
      color: white; /* White text */
      border: none; /* No border */
      padding: 10px 20px; /* Top/bottom and left/right padding */
      font-size: 16px; /* Font size */
      margin: 10px 0; /* Margin above and below */
      cursor: pointer; /* Pointer cursor on hover */
      border-radius: 5px; /* Rounded corners */
      transition: background-color 0.3s; /* Smooth background color transition */
    }

    .start-quiz:hover {
      background-color: #0056b3; /* Darker blue on hover */
    }

/* Updated Highlighted Logout Button Styles */
.logout-button {
    background-color: #ffffff; /* White background */
    color: #000000 !important; /* Black text */
    padding: 20px 24px; /* Top/Bottom and Left/Right padding */
    border: 2px ; /* Black border for prominence */
    border-radius: 25px; /* Pill-shaped rounded corners */
    margin-left: 15px; /* Space from other nav items */
    transition: background-color 0.3s, color 0.3s, transform 0.2s, box-shadow 0.3s; /* Smooth transitions */
    font-weight: bold; /* Bold text */
    font-size: 16px; /* Font size */
    display: flex; /* Flex layout for icon and text */
    align-items: center; /* Vertically center the content */
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1); /* Subtle shadow */
    text-decoration: none; /* Remove underline */
}

.logout-button i {
    margin-right: 8px; /* Space between icon and text */
    font-size: 18px; /* Icon size */
}

.logout-button:hover {
    background-color: #f8f9fa; /* Light gray background on hover */
    color: #dc3545; /* Change text color to Bootstrap's danger color (red) on hover */
    transform: translateY(-2px) scale(1.02); /* Slight lift and scale on hover */
    box-shadow: 0 6px 8px rgba(0, 0, 0, 0.15); /* Enhanced shadow on hover */
}


  </style>
</head>
<body>

<!-- Header -->
<header>
    <div class="header">
       <div class="container-fluid">
          <div class="row">
             <div class="col-xl-3 col-lg-3 col-md-3 col-sm-3 col logo_section">
                <div class="full">
                   <div class="center-desk">
                      <div class="logo">
                         <a href="index.html"><img src="images/log1.png" alt="Logo" /></a>
                      </div>
                   </div>
                </div>
             </div>
             <div class="col-xl-9 col-lg-9 col-md-9 col-sm-9">
                <div class="header_information">
                   <nav class="navigation navbar navbar-expand-md navbar-dark ">
                      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample04" aria-controls="navbarsExample04" aria-expanded="false" aria-label="Toggle navigation">
                      <span class="navbar-toggler-icon"></span>
                      </button>
                      <div class="collapse navbar-collapse" id="navbarsExample04">
                         <ul class="navbar-nav mr-auto">
                            <li class="nav-item active">
                               <a class="nav-link" href="about.html"> About Us  </a>
                            </li> 
                            <li class="nav-item">
                               <a class="nav-link" href="ourwork.html">Our Work</a>
                            </li>
                            <li class="nav-item">
                               <a class="nav-link" href="contact.html">Contact Us</a>
                            </li>
                            <!-- Highlighted Logout Button -->
                            <li class="nav-item">
                               <a class="nav-link logout-button" href="logout.php" onclick="return confirm('Are you sure you want to logout?');">Logout</a>
                            </li>
                         </ul>
                      </div>
                   </nav>
                </div>
             </div>
          </div>
       </div>
    </div>
</header>

<!-- Profile Container -->
<div class="profile-container" style="min-height: 800px; padding: 20px;">
  <!-- Profile Header: Picture and Basic Info -->
  <div class="profile-header">
    <img src="images/cross_img.jpg" alt="Profile Picture" class="profile-picture">
    <div class="profile-info">
      <h2>Welcome <?php echo htmlspecialchars($username); ?></h2> <!-- Employee Name -->
      <p style="color: black;">Employee ID: <?php echo htmlspecialchars($employeeid); ?></p> <!-- Employee ID -->
      <p style="color: black;">Email: <?php echo htmlspecialchars($email); ?></p>     
      <p style="color: black;">Position: <?php echo htmlspecialchars($position); ?></p> <!-- Employee Position -->
    </div>
  </div>

  <!-- Employee Details Section -->
  <div class="profile-section">
    <h3>Employee Details</h3>
    <p>The employee with the username <?php echo htmlspecialchars($username); ?> is registered with the email address <?php echo htmlspecialchars($email); ?>. They are identified by the employee ID <?php echo htmlspecialchars($employeeid); ?> and hold the position of <?php echo htmlspecialchars($position); ?> within the organization.</p>
  </div>

  <!-- Security Awareness Knowledge Check Section -->
  <div class="profile-section">
    <h3>Security Awareness Knowledge Check</h3>
    <p>This quiz checks your current security knowledge. No pressure—just answer honestly to help us guide future training!</p>
    <a href="quiz.html"><button class="start-quiz">Start Quiz</button></a>
  </div>

  <!-- Quiz Progress Section -->
  <div class="profile-section">
      <h3>Quiz Progress</h3>
      <div class="quiz-progress">
          <div class="quiz-progress-bar"><?php echo htmlspecialchars($beginnerProgress); ?>%</div>
      </div>
      <p class="quiz-progress-score">Quiz Progress: <?php echo htmlspecialchars($beginnerProgress); ?>%</p>
      <p class="first Attempt Score">first Attempt Score: <?php echo htmlspecialchars($firstAttemptScore ); ?> / 20</p>
      <p class="first Attempt Status ">first Attempt Status : <?php echo htmlspecialchars($firstAttemptStatus  ); ?></p>
      <p class="last Attempt Score ">last Attempt Score : <?php echo htmlspecialchars($lastAttemptScore  ); ?> / 20</p>
      <p class="last Attempt Status ">last Attempt Status : <?php echo htmlspecialchars($lastAttemptStatus  ); ?></p>
    </div>

  <!-- Future Learning Path Section -->
  <div class="profile-section">
        <h3>Future Learning Path</h3>
        <!-- Dynamically set the link based on the first_attempt_status -->
        <?php
         if ($firstAttemptStatus == 'Expert' || $lastAttemptStatus == 'Expert') {
            // Expert level, show the Generate Certificate button
            echo '<a href="E-certificate/certificate.php"><button class="start-quiz">Generate Certificate</button></a>';
         } elseif ($firstAttemptStatus == 'Intermediate') {
            // Intermediate level, show the Continue Learning button
            echo '<a href="intermediate.html"><button class="start-quiz">Continue Learning</button></a>';
         } elseif ($firstAttemptStatus == 'Beginner') {
            // Beginner level, show the Continue Learning button
            echo '<a href="beginner.html"><button class="start-quiz">Continue Learning</button></a>';
         } else {
            // Default fallback (if no valid status is found)
            echo '<a href="#"><button class="start-quiz" disabled>No Learning Path Available</button></a>';
         }
         ?>
    </div>
</div>

<!-- Footer -->
<footer>
         <div class="footer">
            <div class="container">
               <div class="row border-top">
                  <div class="col-md-6 padding_bottom1">
                     <h3>Subscribe Now</h3>
                     <form class="footer_form">
                        <input class="enter" placeholder="Enter your email" type="email" name="email" required>
                        <button class="submit" type="submit">Submit</button>
                     </form>
                  </div>
                  <div class="col-md-6">
                     <div class="row">
                        <div class="col-md-5 offset-md-1">
                           <ul class="location_icon">
                              <li> <a href="#"><i class="fa fa-facebook-f"></i></a></li>
                              <li> <a href="#"><i class="fa fa-twitter"></i></a></li>
                              <li> <a href="#"><i class="fa fa-instagram"></i></a></li>
                              <li> <a href="#"><i class="fa fa-linkedin"></i></a></li>
                           </ul>
                        </div>
                        <div class="col-md-6">
                           <ul class="location_icon">
                              <li><a href="#"><i class="fa fa-map-marker"></i></a></li>
                              <li><a href="#"><i class="fa fa-phone"></i></a></li>
                              <li><a href="#"><i class="fa fa-envelope"></i></a></li>
                           </ul>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </footer>
   <script>
      document.addEventListener("DOMContentLoaded", function () {
         // Retrieve progress values from session storage (or use PHP-generated value from the session)
         const beginnerProgress = <?php echo isset($beginnerProgress) ? $beginnerProgress : 0; ?>;

         // Find the progress bar and progress score text elements
         const progressBar = document.querySelector('.quiz-progress-bar');
         const quizProgressScore = document.querySelector('.quiz-progress-score');

         // Set the progress bar's width and text content to the beginnerProgress value
         progressBar.style.width = beginnerProgress + '%';
         progressBar.textContent = beginnerProgress + '%';

         // Update the text under the progress bar to reflect the progress
         quizProgressScore.textContent = 'Quiz Progress: ' + beginnerProgress + '%';
      });
   </script>


   <!-- Optional JavaScript -->
   <script src="js/jquery.min.js"></script>
   <script src="js/popper.min.js"></script>
   <script src="js/bootstrap.bundle.min.js"></script>
   <script src="js/jquery.mCustomScrollbar.concat.min.js"></script>

</body>
</html>
