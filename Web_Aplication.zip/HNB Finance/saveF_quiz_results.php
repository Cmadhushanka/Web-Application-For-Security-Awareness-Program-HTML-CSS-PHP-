<?php
session_start();

// Check if session contains employeeid, and POST data contains score and status
if (isset($_SESSION['employeeid']) && isset($_POST['scoreF']) && isset($_POST['statusF'])) {
    $employeeid = $_SESSION['employeeid']; // Get employee ID from session
    $lastAttemptScore = $_POST['scoreF'];   // Score from POST data
    $lastAttemptStatus = $_POST['statusF']; // Status from POST data

    // Database connection
    include 'connect.php';  // Include your DB connection file

    // Check if a record exists for this employeeid
    $sql = "SELECT * FROM marks WHERE employeeid = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $employeeid);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // Record exists, update only the last attempt score and status
        $sql = "UPDATE marks SET last_attempt_score = ?, last_attempt_status = ? WHERE employeeid = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("isi", $lastAttemptScore, $lastAttemptStatus, $employeeid);
    } else {
        // If no record exists, insert a new row with the last attempt data
        $sql = "INSERT INTO marks (employeeid, last_attempt_score, last_attempt_status) VALUES (?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("iis", $employeeid, $lastAttemptScore, $lastAttemptStatus);
    }

    // Execute the query (either insert or update)
    if ($stmt->execute()) {
        echo "Quiz results saved successfully.";
    } else {
        echo "Error: " . $stmt->error;
    }

    // Close statement and connection
    $stmt->close();
    $conn->close();
} else {
    echo "Invalid request or session expired.";
}
?>
