<?php
// Database connection details
$host = 'localhost';  // Replace with your host
$db = 'taprogram1';    // Replace with your database name
$user = 'root';       // Replace with your database username
$pass = '';           // Replace with your database password

// Create PDO connection
try {
    $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8mb4", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    error_log("Database Connection Error: " . $e->getMessage());
    echo "An error occurred while connecting to the database.";
    exit();
}

// Check if ID is provided
if (isset($_GET['id'])) {
    $userId = $_GET['id'];

    // Fetch user data based on ID
    $stmt = $pdo->prepare("SELECT * FROM users WHERE employeeid = :id");
    $stmt->bindParam(':id', $userId);
    $stmt->execute();
    $user = $stmt->fetch();

    if (!$user) {
        echo "User not found.";
        exit();
    }
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $email = $_POST['email'];
    $position = $_POST['position'];

    // Update user in the database
    $stmt = $pdo->prepare("UPDATE users SET username = :username, email = :email, position = :position WHERE employeeid = :id");
    $stmt->bindParam(':username', $username);
    $stmt->bindParam(':email', $email);
    $stmt->bindParam(':position', $position);
    $stmt->bindParam(':id', $userId);

    if ($stmt->execute()) {
        header("Location: admin.php"); // Redirect back to dashboard
        exit();
    } else {
        echo "Failed to update user.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit User</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <style>
        body {
            background-color: #e9ecef;
        }
        .container {
            margin-top: 50px;
        }
    </style>
</head>
<body>
<div class="container">
    <h2>Edit User</h2>
    <form method="POST">
        <div class="form-group">
            <label for="username">Username</label>
            <input type="text" class="form-control" name="username" value="<?php echo htmlspecialchars($user['username']); ?>" required>
        </div>
        <div class="form-group">
            <label for="email">Email</label>
            <input type="email" class="form-control" name="email" value="<?php echo htmlspecialchars($user['email']); ?>" required>
        </div>
        <div class="form-group">
            <label for="position">Position</label>
            <input type="text" class="form-control" name="position" value="<?php echo htmlspecialchars($user['position']); ?>" required>
        </div>
        <button type="submit" class="btn btn-primary">Update User</button>
        <a href="admin_dashboard.php" class="btn btn-secondary">Cancel</a>
    </form>
</div>
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.bundle.min.js"></script>
</body>
</html>
