<?php
// Database connection details
$host = 'localhost';  // Replace with your host
$db = 'taprogram1';    // Replace with your database name
$user = 'root';       // Replace with your database username
$pass = '';           // Replace with your database password

// Create PDO connection
try {
    $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8mb4", $user, $pass);
    // Set PDO error mode to exception
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    // Set default fetch mode to associative array
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    // Log the error message to a file for debugging (do not display in production)
    error_log("Database Connection Error: " . $e->getMessage());
    // Display a generic error message to the user
    echo "An error occurred while connecting to the database.";
    exit(); // Terminate the script
}
?>
<!DOCTYPE html>
<html lang="en">
<head>

      <!-- basic -->
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <!-- mobile metas -->
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta name="viewport" content="initial-scale=1, maximum-scale=1">
      <!-- site metas -->
      <title>blueneek</title>
      <meta name="keywords" content="">
      <meta name="description" content="">
      <meta name="author" content="">
      <!-- bootstrap css -->
      <link rel="stylesheet" href="css/bootstrap.min.css">
      <!-- style css -->
      <link rel="stylesheet" href="css/style.css">
      <!-- Responsive-->
      <link rel="stylesheet" href="css/responsive.css">
      <!-- fevicon -->
      <link rel="icon" href="images/fevicon.png" type="image/gif" />
      <!-- Scrollbar Custom CSS -->
      <link rel="stylesheet" href="css/jquery.mCustomScrollbar.min.css">
      <!-- Tweaks for older IEs-->
      <link rel="stylesheet" href="https://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.css" media="screen">
      <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script><![endif]-->
  <style>
    /* Your existing styles here */
    /* ... */
    body {
      font-family: Arial, sans-serif;
      background-color: #e9ecef;
      margin: 0;
      padding: 0;
      scroll-behavior: smooth; /* Enables smooth scrolling */
    }
    .admin-container {
      display: flex;
      min-height: 100vh;
    }
    /* Sidebar */
    .sidebar {
  width: 250px;
  background-color: #343a40;
  color: white;
  padding: 20px;
  position: fixed; /* Fixes sidebar in the viewport */
  top: 0;          /* Aligns with the top of the page */
  bottom: 0;       /* Extends to the bottom */
  overflow-y: auto; /* Allows scrolling if necessary */
}
    .sidebar .logo {
      text-align: center;
      margin-bottom: 30px;
    }
    .sidebar .logo img {
      width: 100%;
      
    }
    .sidebar ul {
      list-style-type: none;
      padding: 0;
    }
    .sidebar ul li {
      padding: 15px 10px;
      cursor: pointer;
    }
    .sidebar ul li:hover {
      background-color: #495057;
    }
    .sidebar ul li a {
      color: white;
      text-decoration: none;
      display: block;
    }
    /* Main Content */
    .main-content {
      flex: 1;
      padding: 30px;
      margin-left: 250px; /* Adds left margin to accommodate fixed sidebar */
      background-color: #f8f9fa;
    }
    .main-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 30px;
    }
    .main-header h2 {
      margin: 0;
    }
    .profile-info {
      display: flex;
      align-items: center;
    }
    .profile-info img {
      border-radius: 50%;
      width: 50px;
      height: 50px;
      object-fit: cover;
      margin-right: 10px;
    }
    /* Sections */
    .section {
      margin-bottom: 50px;
    }
    /* Tables */
    table {
      width: 100%;
      border-collapse: collapse;
      background-color: white;
    }
    table th, table td {
      padding: 12px;
      border: 1px solid #dee2e6;
      text-align: left;
    }
    table th {
      background-color: #343a40;
      color: white;
    }
    /* Buttons */
    .btn {
      padding: 6px 12px;
      border: none;
      border-radius: 4px;
      cursor: pointer;
      text-decoration: none;
      color: white;
    }
    .btn-edit {
      background-color: #28a745;
    }
    .btn-delete {
      background-color: #dc3545;
    }
    .btn-add {
      background-color: #007bff;
      margin-bottom: 20px;
    }
    /* Responsive */
    @media (max-width: 768px) {
      .admin-container {
        flex-direction: column;
      }
      .sidebar {
        width: 100%;
        height: auto;
        position: relative;
      }
      .main-content {
        margin-left: 0;
        padding: 20px;
      }
      .card-body{
        color:#00AEEF;
      }
    }
  </style>
</head>
<body>
<header>
         <!-- header inner -->
         <div class="header">
            <div class="container-fluid">
               <div class="row">
                  <div class="col-xl-3 col-lg-3 col-md-3 col-sm-3 col logo_section">
                     <div class="full">
                        <div class="center-desk">
                           <div class="logo">
                              <a href="index.html"><img src="images/log1.png" alt="#" /></a>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="col-xl-9 col-lg-9 col-md-9 col-sm-9">
                     <div class="header_information">
                        <nav class="navigation navbar navbar-expand-md navbar-dark ">
                           <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample04" aria-controls="navbarsExample04" aria-expanded="false" aria-label="Toggle navigation">
                           <span class="navbar-toggler-icon"></span>
                           </button>
                           <div class="collapse navbar-collapse" id="navbarsExample04">
                              <ul class="navbar-nav mr-auto">
                                 <li class="nav-item active">
                                    <a class="nav-link" href="about.html"> About Us  </a>
                                 </li> 
                                 <!--li class="nav-item">
                                    <a class="nav-link" href="clients.html">Our Clients</a>
                                 </li-->
                                 <li class="nav-item">
                                    <a class="nav-link" href="ourwork.html">Our Work</a>
                                 </li>
                                 <li class="nav-item">
                                    <a class="nav-link" href="contact.html">Contact Us</a>
                                 </li>
                              </ul>
                        
                           </div>
                        </nav>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </header>
  <!-- Admin Container -->
  <div class="admin-container">
    
    <!-- Sidebar -->
    <div class="sidebar">
  <div class="logo">
    <a href="index.html"><img src="images/log1.png" alt="Logo" /></a>
  </div>
  <ul>
    <li><a href="#dashboard-overview"><i class="fa fa-dashboard"></i> Dashboard</a></li>
    <li><a href="#user-management"><i class="fa fa-users"></i> User Management</a></li>
    <li><a href="#quiz-management"><i class="fa fa-question-circle"></i> Quiz Management</a></li>
    <li><a href="logout.php"><i class="fa fa-sign-out"></i> Logout</a></li>
  </ul>
</div>
    
    <!-- Main Content -->
    <div class="main-content">
      
      <!-- Header -->
      <div class="main-header">
        <h2>Admin Dashboard</h2>
        <div class="profile-info">
          <h2>Welcome John Smith</h2>
        </div>
      </div>
      
      <!-- Dashboard Overview Section -->
      <div id="dashboard-overview" class="dashboard-overview section">
        <h3>Dashboard Overview</h3>
        <div class="row">
          <div class="col-md-3">
            <div class="card text-white bg-primary mb-3">
              <div class="card-header">Total Users</div>
              <div class="card-body">
                <h5 class="card-title" style="color:white;">
                  <?php
                    // Fetch total number of users
                    $stmt = $pdo->prepare("SELECT COUNT(*) as total_users FROM users");
                    $stmt->execute();
                    $result = $stmt->fetch();
                    echo htmlspecialchars($result['total_users']);
                  ?>
                </h5>
              </div>
            </div>
          </div>
          <div class="col-md-3">
            <div class="card text-white bg-success mb-3">
              <div class="card-header">Number Of Employeers Attend to Quizzes</div>
              <div class="card-body">
                <h5 class="card-title" style="color:white;">
                  <?php
                     //Fetch total number of active quizzes
                    $stmt = $pdo->prepare("SELECT COUNT(*) as active_quizzes FROM marks ");
                    $stmt->execute();
                    $result = $stmt->fetch();
                    echo htmlspecialchars($result['active_quizzes']);
                  ?>
                </h5>
              </div>
            </div>
          </div>
          <div class="col-md-3">
            <div class="card text-white bg-warning mb-3">
              <div class="card-header">Number of employees were experts on their first attempt</div>
              <div class="card-body">
                <h5 class="card-title" style="color:white;">
                <?php
                  // Assuming $pdo is already defined and connected to your database

                  // Fetch the total number of employees who were 'Expert' in their first attempt
                  $stmt = $pdo->prepare("SELECT COUNT(*) as first_status FROM marks WHERE first_attempt_status = 'Expert'");
                  $stmt->execute();
                  $result = $stmt->fetch();
                  // Output the result
                  echo htmlspecialchars($result['first_status']);
                  ?>
                </h5> <!-- Replace with dynamic data if available -->
              </div>
            </div>
          </div>
          <div class="col-md-3">
            <div class="card text-white bg-danger mb-3">
              <div class="card-header">Number of employees were experts on their first attempt</div>
              <div class="card-body">
                <h5 class="card-title" style="color:white;">
                <?php
                  // Assuming $pdo is already defined and connected to your database

                  // Fetch the total number of employees who were 'Expert' in their first attempt
                  $stmt = $pdo->prepare("SELECT COUNT(*) as last_status FROM marks WHERE last_attempt_status = 'Expert'");
                  $stmt->execute();
                  $result = $stmt->fetch();
                  // Output the result
                  echo htmlspecialchars($result['last_status']);
                  ?>                  
                </h5> <!-- Replace with dynamic data if available -->
              </div>
            </div>
          </div>
        </div>
      </div>
      
      <!-- User Management Section -->
      <div id="user-management" class="user-management section">
        <h3>User Management</h3>
        <a href="add_new_user.html" class="btn btn-add"><i class="fa fa-user-plus"></i> Add New User</a>
        <table>
          <thead>
            <tr>
              <th>User ID</th>
              <th>Username</th>
              <th>Email</th>
              <th>Position</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <?php
              // Fetch all users
              $stmt = $pdo->prepare("SELECT employeeid, username, email, position FROM users");
              $stmt->execute();
              $users = $stmt->fetchAll();

              if ($users) {
                  foreach ($users as $user) {
                      echo "<tr>";
                      echo "<td>" . htmlspecialchars($user['employeeid']) . "</td>";
                      echo "<td>" . htmlspecialchars($user['username']) . "</td>";
                      echo "<td>" . htmlspecialchars($user['email']) . "</td>";
                      echo "<td>" . htmlspecialchars($user['position']) . "</td>";
                      echo "<td>
                              <a href='admin_edit_user.php?id=" . urlencode($user['employeeid']) . "' class='btn btn-edit'><i class='fa fa-edit'></i> Edit</a>
                              <a href='admin_delete_user.php?id=" . urlencode($user['employeeid']) . "' class='btn btn-delete' onclick=\"return confirm('Are you sure you want to delete this user?');\"><i class='fa fa-trash'></i> Delete</a>
                            </td>";
                      echo "</tr>";
                  }
              } else {
                  echo "<tr><td colspan='5'>No users found.</td></tr>";
              }
            ?>
          </tbody>
        </table>
      </div>
      
      <!-- Quiz Management Section -->
      <div id="quiz-management" class="quiz-management section">
        <h3>Employeer's Marks</h3>
       
        <table>
          <thead>
            <tr>
              <th>Employee ID</th>
              <th>First Attempt Score</th>
              <th>First Attempt Status</th>
              <th>Last Attempt Score</th>
              <th>Last Attempt Status	</th>
              <th>Action	</th>
            </tr>
          </thead>
          <tbody>
            <?php
              // Fetch all quizzes
              $stmt = $pdo->prepare("SELECT employeeid, first_attempt_score, first_attempt_status, last_attempt_score,last_attempt_status FROM marks");
              $stmt->execute();
              $quizzes = $stmt->fetchAll();

              if ($quizzes) {
               foreach ($quizzes as $quiz) {
                      echo "<tr>";
                      echo "<td>" . htmlspecialchars($quiz['employeeid']) . "</td>";
                      echo "<td>" . htmlspecialchars($quiz['first_attempt_score']) . "</td>";
                      echo "<td>" . htmlspecialchars($quiz['first_attempt_status']) . "</td>";
                      echo "<td>" . htmlspecialchars($quiz['last_attempt_score']) . "</td>";
                      echo "<td>" . htmlspecialchars($quiz['last_attempt_status']) . "</td>";
                      echo "<td>
                              <a href='admin_edit_quiz.php?id=" . urlencode($quiz['employeeid']) . "' class='btn btn-edit'><i class='fa fa-edit'></i> Edit</a>
                              <a href='admin_delete_quiz.php?id=" . urlencode($quiz['employeeid']) . "' class='btn btn-delete' onclick=\"return confirm('Are you sure you want to delete this quiz?');\"><i class='fa fa-trash'></i> Delete</a>
                            </td>";
                      echo "</tr>";
                  }
              } else {
                  echo "<tr><td colspan='5'>No quizzes found.</td></tr>";
              }
            ?>
          </tbody>
        </table>
      </div>
      
    </div>
    
  </div>

  <!-- Footer -->
  <footer>
    <div class="footer bg-dark text-white text-center py-3">
      &copy; <?php echo date("Y"); ?> Your Company. All rights reserved.
    </div>
  </footer>

  <!-- Optional JavaScript -->
  <script src="js/jquery.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.bundle.min.js"></script>
  <script src="js/jquery.mCustomScrollbar.concat.min.js"></script>
  <!-- Chart.js for Statistics -->
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  
</body>
</html>
