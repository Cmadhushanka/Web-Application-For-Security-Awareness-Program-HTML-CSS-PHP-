function checkPassword() {
    let password = document.getElementById("password").value;
    let confirm_password = document.getElementById("confirm_password").value;
    
    // Regular expression to ensure at least one of each: lower case, upper case, number, special character, and minimum 8 characters
    let passwordPattern = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&#])[A-Za-z\d@$!%*?&#]{8,}$/;

    if (!passwordPattern.test(password)) {
        alert("Password must be at least 8 characters long and include an uppercase letter, a lowercase letter, a number, and a special character.");
        return false;
    }

    if (password !== confirm_password) {
        alert("Passwords do not match.");
        return false;
    }

    return true;
}

