// Variables
const startBtn = document.querySelector('.start-btn');
const popupInfo = document.querySelector('.popup-info');
const exitBtn = document.querySelector('.exit-btn');
const main = document.querySelector('.main');
const continueBtn = document.querySelector('.continue-btn');
const quizSection = document.querySelector('.quiz-section');
const quizBox = document.querySelector('.quiz-box');
const resultBox = document.querySelector('.result-box');
const ProfileBtn = document.querySelector('.Profile-btn');
const goHomeBtn = document.querySelector('.goHome-btn');

let questionCount = 0;
let questionNumb = 1;
let userScore = 0;

const nextBtn = document.querySelector('.next-btn');

// Event Listeners
startBtn.onclick = () => {
    popupInfo.classList.add('active');
    main.classList.add('active');
};

exitBtn.onclick = () => {
    popupInfo.classList.remove('active');
    main.classList.remove('active');
};

continueBtn.onclick = () => {
    quizSection.classList.add('active');
    popupInfo.classList.remove('active');
    main.classList.remove('active');
    quizBox.classList.add('active');
    showQuestions(0);
    questionCounter(1);
    headerScore();
};

ProfileBtn.onclick = () => {
    resetQuiz();
    window.location.href = "profile.php";
};

goHomeBtn.onclick = () => {
    resetQuiz();
};

// Show Questions Function
function showQuestions(index) {
    const questionText = document.querySelector('.question-text');
    questionText.textContent = `${questions[index].numb}. ${questions[index].question}`;
    let optionTag = questions[index].options.map(option => `<div class="option">${option}</div>`).join('');
    document.querySelector('.option-list').innerHTML = optionTag;

    document.querySelectorAll('.option').forEach(option => {
        option.onclick = () => optionSelected(option);
    });
}

function optionSelected(answer) {
    let userAnswer = answer.textContent;
    let correctAnswer = questions[questionCount].answer;
    if (userAnswer === correctAnswer) {
        userScore++;
        headerScore();
        answer.classList.add('correct');
    } else {
        answer.classList.add('incorrect');
    }
    document.querySelectorAll('.option').forEach(option => option.classList.add('disabled'));
    nextBtn.classList.add('active');
}

// Next Button Functionality
nextBtn.onclick = () => {
    if (questionCount < questions.length - 1) {
        questionCount++;
        questionNumb++;
        showQuestions(questionCount);
        questionCounter(questionNumb);
        nextBtn.classList.remove('active');
    } else {
        showResultBox();
    }
};

// Display Result
function showResultBox() {
    quizBox.classList.remove('active');
    resultBox.classList.add('active');
    document.querySelector('.score-text').textContent = `Your Score ${userScore} out of ${questions.length}`;
    calculateCircularProgress(userScore);
}

// Circular Progress Functionality
function calculateCircularProgress(score) {
    const circularProgress = document.querySelector('.circular-progress');
    const progressValue = document.querySelector('.progress-value');
    let progressStartValue = 0;
    let progressEndValue = (score / 20) * 100;
    let speed = 20;

    let progress = setInterval(() => {
        progressStartValue++;
        progressValue.textContent = `${progressStartValue}%`;
        circularProgress.style.background = `conic-gradient(#AA2C86 ${progressStartValue * 3.6}deg, rgba(255, 255, 255, .1) 0deg)`;
        if (progressStartValue >= progressEndValue) {
            clearInterval(progress);
        }
    }, speed);
}

// Question Counter
function questionCounter(index) {
    document.querySelector('.question-total').textContent = `${index} of ${questions.length} Questions`;
}

// Header Score Update
function headerScore() {
    document.querySelector('.header-score').textContent = `Score: ${userScore} / 20`;
}

// Save Score Button
document.querySelector('.sve-score-btn').addEventListener('click', function () {
    console.log("Save score button clicked!"); // Debug log
    let xhr = new XMLHttpRequest();
    xhr.open('POST', 'save_quiz_results.php', true);
    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    xhr.onreadystatechange = function () {
        if (xhr.readyState == 4 && xhr.status == 200) {
            console.log('Response received:', xhr.responseText); // Debug log
            alert('Score and status saved successfully!');
        } else if (xhr.readyState == 4 && xhr.status !== 200) {
            console.log('Error:', xhr.status); // Debug log
        }
    };
    let finalScore = userScore;
    let firstAttemptStatus = finalScore <= 10 ? 'Beginner' : finalScore <= 15 ? 'Intermediate' : 'Expert';
    xhr.send(`score=${finalScore}&status=${firstAttemptStatus}`);
});


// Reset Quiz
function resetQuiz() {
    quizSection.classList.remove('active');
    resultBox.classList.remove('active');
    nextBtn.classList.remove('active');
    questionCount = 0;
    questionNumb = 1;
    userScore = 0;
    showQuestions(questionCount);
    questionCounter(questionNumb);
}
