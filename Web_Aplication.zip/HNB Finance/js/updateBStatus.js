const startBtn = document.querySelector('.start-btn');
const popupInfo = document.querySelector('.popup-info');
const exitBtn = document.querySelector('.exit-btn');
const main = document.querySelector('.main');
const continueBtn = document.querySelector('.continue-btn');
const quizSection = document.querySelector('.quiz-section');
const quizBox = document.querySelector('.quiz-box');
const resultBox = document.querySelector('.result-box');
const ProfileBtn = document.querySelector('.Profile-btn');
const goHomeBtn = document.querySelector('.goHome-btn');
const nextBtn = document.querySelector('.next-btn');
const optionList = document.querySelector('.option-list');
const updateStatusBtn = document.querySelector('.update-status-btn'); // Add this here for status update button
let questionCount = 0;
let questionNumb = 1;
let userScore = 0;
const totalQuestions = 20; // Total number of questions

// Start the quiz by showing the quiz box
startBtn.onclick = () => {
    popupInfo.classList.add('active');
    main.classList.add('active');
};

// Close the popup
exitBtn.onclick = () => {
    popupInfo.classList.remove('active');
    main.classList.remove('active');
};

// Continue to the quiz section
continueBtn.onclick = () => {
    quizSection.classList.add('active');
    popupInfo.classList.remove('active');
    main.classList.remove('active');
    quizBox.classList.add('active');

    showQuestions(0); // Start by showing the first question
    questionCounter(1); // Start the question counter
    headerScore(); // Display initial score
};

// Go to profile after quiz is completed
ProfileBtn.onclick = () => {
    resetQuiz(); // Reset quiz for future attempts
    window.location.href = "profile.php"; // Redirect to profile
};

// Return to home after the quiz
goHomeBtn.onclick = () => {
    resetQuiz(); // Reset quiz for future attempts
};

// Handle the "Next" button click
nextBtn.onclick = () => {
    if (questionCount < questions.length - 1) {
        questionCount++;
        showQuestions(questionCount); // Show the next question
        questionNumb++;
        questionCounter(questionNumb); // Update the question counter
        nextBtn.classList.remove('active'); // Deactivate the "Next" button until an answer is selected
    } else {
        showResultBox(); // Show results when all questions are answered
    }
};

// Display questions and options from the questions array
function showQuestions(index) {
    const questionText = document.querySelector('.question-text');
    questionText.textContent = `${questions[index].numb}. ${questions[index].question}`;

    let optionTag = `<div class="option"><span>${questions[index].options[0]}</span></div>
        <div class="option"><span>${questions[index].options[1]}</span></div>
        <div class="option"><span>${questions[index].options[2]}</span></div>
        <div class="option"><span>${questions[index].options[3]}</span></div>`;
    
    optionList.innerHTML = optionTag;

    const options = document.querySelectorAll('.option');
    options.forEach(option => {
        option.setAttribute('onclick', 'optionSelected(this)');
    });
}

// Handle option selection
function optionSelected(answer) {
    let userAnswer = answer.textContent;
    let correctAnswer = questions[questionCount].answer;

    if (userAnswer === correctAnswer) {
        answer.classList.add('correct');
        userScore++; // Increment score if the answer is correct
        headerScore(); // Update score in the header
    } else {
        answer.classList.add('incorrect');
    }

    // Disable all options after selection
    for (let i = 0; i < optionList.children.length; i++) {
        optionList.children[i].classList.add('disabled');
    }

    // Activate the "Next" button after selecting an option
    nextBtn.classList.add('active');
}

// Update the question counter (Progress of the quiz)
function questionCounter(index) {
    const questionTotal = document.querySelector('.question-total');
    questionTotal.textContent = `${index} of ${questions.length} Questions`; // This shows progress of the quiz
}

// Update the score display in the header (Score Obtained)
function headerScore() {
    const headerScoreText = document.querySelector('.header-score');
    headerScoreText.textContent = `Score: ${userScore} / ${totalQuestions}`; // This shows the score obtained
}

// Display the result box after the quiz is completed (Score Obtained)
function showResultBox() {
    quizBox.classList.remove('active');
    resultBox.classList.add('active');

    const scoreText = document.querySelector('.score-text');
    scoreText.textContent = `Your Score ${userScore} out of ${questions.length}`;

    const circularProgress = document.querySelector('.circular-progress');
    const progressValue = document.querySelector('.progress-value');

    let progressStartValue = 0; // Start from 0%
    let progressEndValue = (userScore / 20) * 100; // 20 is the number of questions
    let speed = 20;

    // Store progressEndValue in sessionStorage
    sessionStorage.setItem('progressEndValue', progressEndValue);

    let progress = setInterval(() => {
        progressStartValue++;
        progressValue.textContent = `${progressStartValue}%`;
        circularProgress.style.background = `conic-gradient(#AA2C86 ${progressStartValue * 3.6}deg, rgba(255, 255, 255, .1) 0deg)`;
        if (progressStartValue >= progressEndValue) { // Use >= to ensure it doesn't stop early
            clearInterval(progress);
        }
    }, speed);

    // Store score for status update
    sessionStorage.setItem('userScore', userScore); // Save score for later
}

// Reset the quiz for future attempts
function resetQuiz() {
    quizSection.classList.remove('active');
    resultBox.classList.remove('active');
    nextBtn.classList.remove('active');
    questionCount = 0;
    questionNumb = 1;
    userScore = 0;
    showQuestions(questionCount); // Reset to first question
    questionCounter(questionNumb); // Reset question counter
}

// Handle the status update logic
updateStatusBtn.onclick = () => {
    let userScore = sessionStorage.getItem('userScore'); // Retrieve the stored score
    userScore = Number(userScore); // Ensure score is a number
    
    console.log("User Score: ", userScore); // Log the retrieved score for debugging

    let newStatus = "Beginner"; // Default status

    // Update to Intermediate if the score is more than 3
    if (userScore > 14) {
        newStatus = "Intermediate";
    }

    // AJAX request to send the updated status to the server
    const xhr = new XMLHttpRequest();
    xhr.open("POST", "updateBStatus.php", true); // Ensure `updateBStatus.php` handles the update logic
    xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

    xhr.onreadystatechange = function () {
        if (xhr.readyState == 4 && xhr.status == 200) {
            alert(xhr.responseText); // Show a message based on the server's response
        }
    };

    // Send the new status to the server
    xhr.send("status=" + newStatus);
};
