// Function to check quiz answers
function checkAnswer(questionId, correctAnswer) {
    const radios = document.getElementsByName(questionId);
    let selected = '';
    for (const radio of radios) {
        if (radio.checked) {
            selected = radio.value;
            break;
        }
    }
    const feedback = document.getElementById(`${questionId}-feedback`);
    if (selected === correctAnswer) {
        feedback.textContent = 'Correct!';
        feedback.classList.remove('incorrect');
        feedback.classList.add('correct');
    } else {
        feedback.textContent = 'Incorrect. Please try again.';
        feedback.classList.remove('correct');
        feedback.classList.add('incorrect');
    }

    // Check if all quizzes are answered correctly to enable completion button
    checkCompletion();
}

// Function to simulate phishing email identification
function simulatePhishing(feedbackId, isPhishing) {
    const feedback = document.getElementById(feedbackId + '-feedback');
    if (isPhishing) {
        feedback.textContent = 'Correct! This is a phishing email.';
        feedback.classList.remove('incorrect');
        feedback.classList.add('correct');
    } else {
        feedback.textContent = 'Incorrect. This is a legitimate email.';
        feedback.classList.remove('correct');
        feedback.classList.add('incorrect');
    }

    // Check if all quizzes are answered correctly to enable completion button
    checkCompletion();
}

// Function to check password strength
function checkPasswordStrength() {
    const password = document.getElementById('password-input').value;
    const feedback = document.getElementById('password-feedback');
    let strength = 'Weak';

    // Simple password strength check
    if (password.length >= 12 && /[A-Z]/.test(password) && /[a-z]/.test(password) &&
        /[0-9]/.test(password) && /[!@#$%^&*(),.?":{}|<>]/.test(password)) {
        strength = 'Strong';
        feedback.classList.add('correct');
        feedback.classList.remove('incorrect');
    } else if (password.length >= 8) {
        strength = 'Moderate';
        feedback.classList.remove('correct');
        feedback.classList.remove('incorrect');
    } else {
        strength = 'Weak';
        feedback.classList.add('incorrect');
        feedback.classList.remove('correct');
    }

    feedback.textContent = `Password Strength: ${strength}`;
}

// Function to check if all quizzes are answered correctly
function checkCompletion() {
    const feedbackElements = document.querySelectorAll('.feedback.correct');
    // Total quizzes: 6 (one per step)
    if (feedbackElements.length >= 6) {
        document.getElementById('complete-btn').disabled = false;
    }
}

// Function to handle completion
function completePath() {
    const completionMessage = document.getElementById('completion-message');
    const certificate = document.getElementById('certificate');
    completionMessage.textContent = 'Congratulations! You have completed the Beginner Level of Cybersecurity Awareness.';
    certificate.style.display = 'block';
    // Optionally, trigger a download of the certificate
    // window.location.href = 'images/certificate.png'; // Simple approach
}


