let questions = [
    {
        numb: 1,
        question: "What is the primary goal of a firewall?",
        answer: "B. To block unauthorized access",
        options: [
          "A. To detect malware",
          "B. To block unauthorized access",
          "C. To scan for viruses",
          "D. To monitor employee activity"
        ]
      },
      {
        numb: 2,
        question: "Which of the following is considered strong password practice?",
        answer: "C. Using a combination of letters, numbers, and symbols",
        options: [
          "A. Using '12345'",
          "B. Reusing the same password across accounts",
          "C. Using a combination of letters, numbers, and symbols",
          "D. Using only lowercase letters"
        ]
      },
      {
        numb: 3,
        question: "What does the term 'phishing' refer to?",
        answer: "B. Tricking someone into giving personal information",
        options: [
          "A. Catching fish using technology",
          "B. Tricking someone into giving personal information",
          "C. Encrypting data for security",
          "D. Installing a firewall"
        ]
      },
      {
        numb: 4,
        question: "What does 'https' signify on a website?",
        answer: "C. The connection is encrypted",
        options: [
          "A. The website is a government site",
          "B. The site is a social media platform",
          "C. The connection is encrypted",
          "D. It's a blog site"
        ]
      },
      {
        numb: 5,
        question: "Which of these is an example of social engineering?",
        answer: "B. An attacker tricking someone into giving confidential information",
        options: [
          "A. Using strong passwords",
          "B. An attacker tricking someone into giving confidential information",
          "C. Installing antivirus software",
          "D. Sending encrypted emails"
        ]
      },
      {
        numb: 6,
        question: "What is the most secure way to manage your passwords?",
        answer: "C. Use a password manager",
        options: [
          "A. Write them down in a notebook",
          "B. Memorize all passwords",
          "C. Use a password manager",
          "D. Reuse the same password for all accounts"
        ]
      },
      {
        numb: 7,
        question: "What is two-factor authentication (2FA)?",
        answer: "B. An additional layer of security requiring two verification methods",
        options: [
          "A. A second type of password",
          "B. An additional layer of security requiring two verification methods",
          "C. A backup method for accessing an account",
          "D. An encryption tool"
        ]
      },
      {
        numb: 8,
        question: "What should you do if you receive a suspicious email with a link?",
        answer: "C. Report the email to IT and do not click the link",
        options: [
          "A. Click the link immediately",
          "B. Ignore the email",
          "C. Report the email to IT and do not click the link",
          "D. Forward the email to a colleague"
        ]
      },
      {
        numb: 9,
        question: "What is the safest practice when using public Wi-Fi?",
        answer: "B. Use a virtual private network (VPN)",
        options: [
          "A. Connect directly without security",
          "B. Use a virtual private network (VPN)",
          "C. Share sensitive data freely",
          "D. Disable your device’s firewall"
        ]
      },
      {
        numb: 10,
        question: "What is a common method attackers use to steal credentials?",
        answer: "A. Sending a malicious link in an email",
        options: [
          "A. Sending a malicious link in an email",
          "B. Using two-factor authentication",
          "C. Backing up data regularly",
          "D. Updating security patches"
        ]
      },
      {
        numb: 11,
        question: "What is a zero-day vulnerability?",
        answer: "A. A vulnerability that is exploited before being discovered",
        options: [
          "A. A vulnerability that is exploited before being discovered",
          "B. A virus that was discovered yesterday",
          "C. A malware that has no cure",
          "D. A known vulnerability with a patch"
        ]
      },
      {
        numb: 12,
        question: "What is the purpose of encryption?",
        answer: "A. To make data unreadable without a decryption key",
        options: [
          "A. To make data unreadable without a decryption key",
          "B. To detect viruses",
          "C. To increase internet speed",
          "D. To back up data"
        ]
      },
      {
        numb: 13,
        question: "What does malware refer to?",
        answer: "A. Software designed to harm or exploit a system",
        options: [
          "A. Software designed to harm or exploit a system",
          "B. A secure type of software",
          "C. A file management tool",
          "D. An email protocol"
        ]
      },
      {
        numb: 14,
        question: "Which of the following is an example of a strong password?",
        answer: "C. T!me2Le@rn",
        options: [
          "A. Password123",
          "B. Abcde123",
          "C. T!me2Le@rn",
          "D. admin1234"
        ]
      },
      {
        numb: 15,
        question: "What is social engineering?",
        answer: "B. Manipulating individuals into divulging confidential information",
        options: [
          "A. A coding technique",
          "B. Manipulating individuals into divulging confidential information",
          "C. Developing secure software",
          "D. A form of network security"
        ]
      },
      {
        numb: 16,
        question: "How often should you update your passwords?",
        answer: "C. Regularly, and immediately if there is a security concern",
        options: [
          "A. Once a year",
          "B. Only when prompted",
          "C. Regularly, and immediately if there is a security concern",
          "D. Never"
        ]
      },
      {
        numb: 17,
        question: "What is a key aspect of multi-factor authentication?",
        answer: "B. Requiring multiple forms of verification, such as a password and a security code",
        options: [
          "A. Using a single password",
          "B. Requiring multiple forms of verification, such as a password and a security code",
          "C. Sharing passwords with colleagues",
          "D. Using an unsecured public Wi-Fi connection"
        ]
      },
      {
        numb: 18,
        question: "What should you do if you think your computer has been infected with malware?",
        answer: "B. Disconnect from the internet and report the issue to IT",
        options: [
          "A. Ignore the problem and continue using the computer",
          "B. Disconnect from the internet and report the issue to IT",
          "C. Download more files",
          "D. Reboot the computer"
        ]
      },
      {
        numb: 19,
        question: "What is the role of antivirus software?",
        answer: "B. To scan and remove malicious software",
        options: [
          "A. To prevent phishing attacks",
          "B. To scan and remove malicious software",
          "C. To increase the speed of your computer",
          "D. To automatically update your operating system"
        ]
      },
      {
        numb: 20,
        question: "What does a secure password policy recommend?",
        answer: "B. Regularly update passwords and use complex combinations",
        options: [
          "A. Use passwords that are easy to remember, like 'password'",
          "B. Regularly update passwords and use complex combinations",
          "C. Share your passwords with trusted colleagues",
          "D. Keep the same password forever"
        ]
      }
      
];