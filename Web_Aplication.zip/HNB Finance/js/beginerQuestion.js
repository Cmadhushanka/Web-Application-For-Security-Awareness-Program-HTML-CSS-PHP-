let questions = [
  {
    numb: 1,
    question: "What should you do if you suspect that your password has been compromised?",
    answer: "A. Change the password immediately",
    options: [
      "A. Change the password immediately",
      "B. Ignore it",
      "C. Write it down somewhere",
      "D. Share it with a colleague"
    ]
  },
  {
    numb: 2,
    question: "What is a 'strong' password?",
    answer: "B. A mix of upper/lowercase letters, numbers, and symbols",
    options: [
      "A. Short and memorable",
      "B. A mix of upper/lowercase letters, numbers, and symbols",
      "C. Only numbers",
      "D. Just your name"
    ]
  },
  {
    numb: 3,
    question: "What is the most common form of phishing attack?",
    answer: "B. An email pretending to be from a trusted source, asking for sensitive info",
    options: [
      "A. A legitimate email",
      "B. An email pretending to be from a trusted source, asking for sensitive info",
      "C. A phone call from your bank",
      "D. Social media post"
    ]
  },
  {
    numb: 4,
    question: "Which of the following is NOT an example of sensitive information?",
    answer: "C. Your favorite color",
    options: [
      "A. Your password",
      "B. Your home address",
      "C. Your favorite color",
      "D. Your bank account number"
    ]
  },
  {
    numb: 5,
    question: "What does it mean to encrypt data?",
    answer: "A. To change it into an unreadable format unless decrypted",
    options: [
      "A. To change it into an unreadable format unless decrypted",
      "B. To delete it permanently",
      "C. To send it over the internet",
      "D. To store it in a physical safe"
    ]
  },
  {
    numb: 6,
    question: "Which of the following is a benefit of two-factor authentication (2FA)?",
    answer: "B. It provides an additional layer of security",
    options: [
      "A. It allows easier access to your account",
      "B. It provides an additional layer of security",
      "C. It makes your password weaker",
      "D. It removes the need for a password"
    ]
  },
  {
    numb: 7,
    question: "If you accidentally click on a phishing link, what should you do first?",
    answer: "B. Report the incident to IT and change your passwords",
    options: [
      "A. Ignore it",
      "B. Report the incident to IT and change your passwords",
      "C. Share the link with friends",
      "D. Turn off your computer"
    ]
  },
  {
    numb: 8,
    question: "Which type of software can help protect your computer from malware?",
    answer: "A. Antivirus software",
    options: [
      "A. Antivirus software",
      "B. Word processor",
      "C. Web browser",
      "D. Media player"
    ]
  },
  {
    numb: 9,
    question: "What is a common sign of a phishing email?",
    answer: "B. Poor grammar and spelling errors",
    options: [
      "A. A trusted company logo",
      "B. Poor grammar and spelling errors",
      "C. A clear subject line",
      "D. Your name spelled correctly"
    ]
  },
  {
    numb: 10,
    question: "What is the primary purpose of a firewall?",
    answer: "A. To block unauthorized access to or from a private network",
    options: [
      "A. To block unauthorized access to or from a private network",
      "B. To increase internet speed",
      "C. To filter email spam",
      "D. To manage passwords"
    ]
  },
  {
    numb: 11,
    question: "What is a key aspect of securing mobile devices?",
    answer: "B. Setting a strong password or using biometric authentication",
    options: [
      "A. Using public Wi-Fi",
      "B. Setting a strong password or using biometric authentication",
      "C. Installing many apps",
      "D. Disabling security features"
    ]
  },
  {
    numb: 12,
    question: "What is social engineering in cybersecurity?",
    answer: "A. Manipulating individuals into divulging confidential information",
    options: [
      "A. Manipulating individuals into divulging confidential information",
      "B. Coding new security systems",
      "C. Installing software updates",
      "D. Creating social media accounts"
    ]
  },
  {
    numb: 13,
    question: "What should you do when you receive an unsolicited attachment in an email?",
    answer: "B. Scan it with antivirus software before opening",
    options: [
      "A. Open it immediately",
      "B. Scan it with antivirus software before opening",
      "C. Share it with a colleague",
      "D. Click on it if it's from someone you know"
    ]
  },
  {
    numb: 14,
    question: "Which of the following is a good practice for creating strong passwords?",
    answer: "B. Use different passwords for different accounts",
    options: [
      "A. Use dictionary words",
      "B. Use different passwords for different accounts",
      "C. Use your birthdate as the password",
      "D. Use only lowercase letters"
    ]
  },
  {
    numb: 15,
    question: "What should you do if your computer is infected with ransomware?",
    answer: "B. Disconnect from the network and report to IT",
    options: [
      "A. Pay the ransom immediately",
      "B. Disconnect from the network and report to IT",
      "C. Continue using the system",
      "D. Restart the computer"
    ]
  },
  {
    numb: 16,
    question: "What is the best way to avoid downloading malware from an email?",
    answer: "A. Open attachments only from trusted sources",
    options: [
      "A. Open attachments only from trusted sources",
      "B. Open all attachments immediately",
      "C. Use public Wi-Fi when downloading",
      "D. Disable your antivirus software"
    ]
  },
  {
    numb: 17,
    question: "Why is it important to regularly update your software?",
    answer: "B. To fix security vulnerabilities and bugs",
    options: [
      "A. To add new features",
      "B. To fix security vulnerabilities and bugs",
      "C. To remove old data",
      "D. To clean your computer"
    ]
  },
  {
    numb: 18,
    question: "How can you verify if a website is secure for online transactions?",
    answer: "B. It has 'https' and a padlock symbol in the URL",
    options: [
      "A. It loads quickly",
      "B. It has 'https' and a padlock symbol in the URL",
      "C. The website has a lot of images",
      "D. It has a short domain name"
    ]
  },
  {
    numb: 19,
    question: "What is a common method for securing sensitive data on your computer?",
    answer: "B. Encrypt the data",
    options: [
      "A. Leave it unprotected",
      "B. Encrypt the data",
      "C. Store it in plain text",
      "D. Share it with everyone"
    ]
  },
  {
    numb: 20,
    question: "What is an example of a multi-factor authentication method?",
    answer: "B. Using a password and a fingerprint scan",
    options: [
      "A. Using a password only",
      "B. Using a password and a fingerprint scan",
      "C. Using your name",
      "D. Using just your email address"
    ]
  }
  
      
];