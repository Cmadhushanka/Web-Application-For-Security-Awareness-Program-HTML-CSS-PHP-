function sanitizeInput(input) {
    return input.replace(/[<>\/\'\"]+/g, "");  // Removes special characters like <, >, /, ', "
}

document.getElementById("login_form").onsubmit = function() {
    let employeeid = document.getElementsByName("employeeid")[0];
    let password = document.getElementsByName("password")[0];
    
    employeeid.value = sanitizeInput(employeeid.value);
    password.value = sanitizeInput(password.value);
    
    return true;
};
