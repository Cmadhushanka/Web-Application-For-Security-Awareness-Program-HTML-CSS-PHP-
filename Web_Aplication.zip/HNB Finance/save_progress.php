<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['beginnerProgress'])) {
        $beginnerProgress = floatval($_POST['beginnerProgress']);
        
        // Save progress to PHP session
        $_SESSION['beginnerProgress'] = $beginnerProgress;
        
        // Optional: Save progress to the database (if necessary)
        //include 'connect.php'; // Database connection file
        // $employeeid = $_SESSION['employeeid'];
        // $sql = "UPDATE users SET beginner_progress = ? WHERE employeeid = ?";
        // $stmt = $conn->prepare($sql);
        // $stmt->bind_param("di", $beginnerProgress, $employeeid);
        // $stmt->execute();
        // $stmt->close();
        // $conn->close();

        echo "Progress saved: " . htmlspecialchars($beginnerProgress) . "%";
    } else {
        echo "No progress data received.";
    }
} else {
    echo "Invalid request method.";
}
?>
