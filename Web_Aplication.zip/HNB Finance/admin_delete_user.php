<?php
// Enable error reporting for debugging (optional)
// error_reporting(E_ALL);
// ini_set('display_errors', 1);

// Ensure database connection is included
require_once 'config.php';  // Ensure this path is correct

// Start output buffering
ob_start();

if (isset($_GET['id'])) {
    $employeeIdToDelete = $_GET['id'];
    
    // Validate the ID (make sure it’s a number)
    if (!is_numeric($employeeIdToDelete)) {
        echo "<script>console.error('Invalid user ID.');</script>";
        exit();
    }

    try {
        // Use the $pdo object created in config.php to prepare the query
        $stmt = $pdo->prepare("DELETE FROM users WHERE employeeid = :employeeid");
        $stmt->execute(['employeeid' => $employeeIdToDelete]);

        // Check if any row was deleted
        if ($stmt->rowCount() > 0) {
            // Redirect back to dashboard or another page after deletion
            header("Location: admin_profile.php");
            exit();
        } else {
            echo "<script>console.warn('No user found with the given ID.');</script>";
        }
    } catch (PDOException $e) {
        // Log error to the console
        echo "<script>console.error('Error deleting user: " . addslashes($e->getMessage()) . "');</script>";
    }
} else {
    echo "<script>console.warn('No user ID provided.');</script>";
}

// Flush output buffer
ob_end_flush();
?>
