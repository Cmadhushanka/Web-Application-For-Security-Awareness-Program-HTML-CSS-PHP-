<?php
$host = "localhost";        // Your server name
$db = "taprogram1";          // Your database name
$username = "root";         // Your database username
$password = "";             // Your database password
$charset = 'utf8mb4';       // Character set

// Define DSN (Data Source Name) for the PDO connection
$dsn = "mysql:host=$host;dbname=$db;charset=$charset";

// PDO options for better error handling and default fetching style
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

// Try connecting to the database using PDO
try {
    $pdo = new PDO($dsn, $username, $password, $options);
} catch (PDOException $e) {
    // Handle connection failure
    die("Connection failed: " . $e->getMessage());
}
?>
