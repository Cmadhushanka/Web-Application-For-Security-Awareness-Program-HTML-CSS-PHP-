<?php

include 'connect.php';

// Get POST data
$employeeid = $_POST["employeeid"];
$username = $_POST["username"];
$position = $_POST["position"];
$email = $_POST["email"];
$password = $_POST["password"];

// Check if employeeid already exists using a prepared statement
$check_query = $conn->prepare("SELECT * FROM users WHERE employeeid = ?");
$check_query->bind_param("s", $employeeid);
$check_query->execute();
$result = $check_query->get_result();

if ($result->num_rows > 0) {
    // If employeeid already exists, show error
    echo "<script>alert('Error: Employee ID already exists')</script>";
} else {
    // Hash the password before inserting into the database
    $hashed_password = password_hash($password, PASSWORD_BCRYPT);

    // Insert new data using a prepared statement (including position)
    $stmt = $conn->prepare("INSERT INTO users (employeeid, username, position, email, password) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("sssss", $employeeid, $username, $position, $email, $hashed_password);

    if ($stmt->execute()) {
        echo "<script>alert('Details inserted successfully')</script>";
    } else {
        echo "<script>alert('Error: Could not insert data')</script>";
    }

    // Close the prepared statement
    $stmt->close();
}

// Close the database connection
$conn->close();

// Redirect after insertion
header("Location: admin_profile.php");

?>
