<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'vendor/autoload.php'; // Include Composer's autoload file to load PHPMailer

include 'connect.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $employeeid = $_POST["employeeid"];
    $password = $_POST["password"];

    // Use prepared statements to prevent SQL injection
    // Add 'position' field to the query to get the user's role (e.g., 'admin' or 'user')
    $stmt = $conn->prepare("SELECT email, password, position FROM admins WHERE employeeid = ?");
    $stmt->bind_param("s", $employeeid);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        $stmt->bind_result($email, $hashed_password, $position); // Fetch 'position' along with email and password
        $stmt->fetch();

        // Verify the password
        if (password_verify($password, $hashed_password)) {
            // Generate OTP
            $otp = rand(100000, 999999); // 6-digit random OTP

            // Store OTP, email, employeeid, and position in session for later verification
            session_start();
            $_SESSION['otp'] = $otp;
            $_SESSION['email'] = $email; // Store the user's email in the session
            $_SESSION['employeeid'] = $employeeid;
            $_SESSION['position'] = $position; // Store the user's position (admin/user)

            // Send OTP to the user's email using PHPMailer
            send_otp($email, $otp); // Send OTP to the relevant user's email

            // Redirect to OTP verification page
            header("Location: verify_otp.html");
            exit();
        } else {
            echo "<script>alert('Invalid Employee ID or Password!')</script>";
        }
    } else {
        echo "<script>alert('Invalid Employee ID or Password!')</script>";
    }

    $stmt->close();
}

// Function to send OTP via email using PHPMailer
function send_otp($email, $otp) {
    $mail = new PHPMailer(true);

    try {
        // Server settings
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com'; // Set the SMTP server to send through
        $mail->SMTPAuth   = true;
        $mail->Username   = 'supithapathirana@gmail.com'; // SMTP username
        $mail->Password   = 'gvdk jhwf wlsm uknx'; // SMTP password
        $mail->SMTPSecure = 'tls';
        $mail->Port       = 587;

        // Recipients
        $mail->setFrom('taprogram99@gmail.com', 'ta');
        $mail->addAddress($email); // Send OTP to the user's email

        // Content
        $mail->isHTML(true);
        $mail->Subject = 'Your OTP Code';
        $mail->Body    = 'Your OTP for login is: ' . $otp;

        $mail->send();
        echo 'OTP has been sent to your email';
    } catch (Exception $e) {
        echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
    }
}
?>
