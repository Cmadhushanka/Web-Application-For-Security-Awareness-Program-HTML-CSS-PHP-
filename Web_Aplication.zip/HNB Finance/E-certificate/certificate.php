<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <!-- Google Font for a modern look -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;500;700&display=swap" rel="stylesheet">
    <title>Certificate Generator</title>
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f8f9fa;
        }
        .container {
            background-color: #fff;
            border-radius: 15px;
            box-shadow: 0px 10px 30px rgba(0, 0, 0, 0.1);
            padding: 30px;
        }
        .form-floating input {
            border-radius: 10px;
            padding: 20px;
            font-size: 1.2rem;
        }
        label {
            font-weight: 500;
            color: #555;
        }
        .btn-outline-info {
            padding: 15px;
            font-size: 1.3rem;
            border-radius: 50px;
        }
        .btn-outline-info:hover {
            background-color: #17a2b8;
            color: white;
        }
        .title {
            font-size: 2rem;
            font-weight: 700;
            margin-bottom: 20px;
            text-align: center;
            color: #333;
        }
        .form-container {
            padding: 40px;
        }
    </style>
</head>
<body>
    <div class="d-flex align-items-center min-vh-100">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-8 form-container">
                    <div class="title">Generate Your Certificate</div>
                    <form action="generator.php" method="post">
                        <div class="form-floating mb-4">
                            <input type="text" class="form-control" name="name" id="floatingInput" placeholder="Enter your name" required>
                            <label for="floatingInput">Enter Your Name</label>
                        </div>
                        <div class="d-grid">
                            <button class="btn btn-outline-info fw-bold" type="submit" name="certificate">Generate Certificate</button>
                        </div>    
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>
</html>
