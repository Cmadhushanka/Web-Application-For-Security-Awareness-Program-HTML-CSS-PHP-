<?php
if(isset($_POST['certificate'])) {
    $Name = $_POST['name'];

    // Set the content type header for PNG
    header('Content-Type: image/png');
    
    // Define the path to the font and load the image
    $font_normal = "IMPRISHA.TTF";
    $image = imagecreatefrompng("certificate.png");

    // Allocate the text color (in RGB)
    $color = imagecolorallocate($image, 19, 21, 22);

    // Define the font size
    $font_size = 50;

    // Get the width of the image
    $image_width = imagesx($image);

    // Calculate the bounding box of the text (used to center text horizontally)
    $text_box = imagettfbbox($font_size, 0, $font_normal, $Name);
    $text_width = $text_box[2] - $text_box[0];

    // Calculate the X coordinate to center the text horizontally
    $x = ($image_width - $text_width) / 2;

    // Y coordinate for the text (adjust according to the image)
    $y = 800;

    // Add the text to the image
    imagettftext($image, $font_size, 0, $x, $y, $color, $font_normal, $Name);

    $fileName = $Name . '.png';

    // Display the image inline and also prompt for download
   
    header('Content-Disposition: attachment; filename="'.$fileName.'"'); // Force download

    // Output the image
    imagepng($image);

    // Free up memory
    imagedestroy($image);
}
?>
