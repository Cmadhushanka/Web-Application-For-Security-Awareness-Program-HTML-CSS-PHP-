<?php
session_start();

// Check if the employee ID exists in the session
if (isset($_SESSION['employeeid'])) {
    $employeeId = $_SESSION['employeeid']; // Use the correct session key

    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $newStatus = $_POST['status'];

        include 'connect.php'; // Include your database connection file

        // Prepare SQL statement to update the employee's status
        $sql = "UPDATE marks SET first_attempt_status = ? WHERE employeeid = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("si", $newStatus, $employeeId);

        if ($stmt->execute()) {
            echo "Status updated successfully to " . $newStatus;
        } else {
            echo "Error updating status: " . $conn->error;
        }

        $stmt->close();
        $conn->close();
    }
} else {
    echo "Employee ID is not set in the session.";
}
?>
