<?php
// Error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Database connection details
$host = 'localhost';  // Replace with your host
$db = 'taprogram1';    // Replace with your database name
$user = 'root';       // Replace with your database username
$pass = '';           // Replace with your database password

// Create PDO connection
try {
    $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8mb4", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    error_log("Database Connection Error: " . $e->getMessage());
    echo "An error occurred while connecting to the database.";
    exit();
}

// Check if employee ID is provided
if (isset($_GET['id'])) {
    $employeeId = $_GET['id'];

    // Fetch marks data based on employee ID
    $stmt = $pdo->prepare("SELECT * FROM marks WHERE employeeid = :id");
    $stmt->bindParam(':id', $employeeId);
    $stmt->execute();
    $employee = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$employee) {
        echo "Employee not found.";
        exit();
    }
} else {
    echo "No employee ID provided.";
    exit();
}

// Handle deletion
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Delete quiz data from the database
    $stmt = $pdo->prepare("DELETE FROM marks WHERE employeeid = :id");
    $stmt->bindParam(':id', $employeeId);

    if ($stmt->execute()) {
        header("Location: admin_profile.php"); // Redirect back to dashboard
        exit();
    } else {
        echo "Failed to delete quiz data.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Delete Quiz for Employee</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <style>
        body {
            background-color: #e9ecef;
        }
        .container {
            margin-top: 50px;
            max-width: 600px; /* Set a max width for the container */
            padding: 30px; /* Add padding for inner spacing */
            background: white; /* Set a background color */
            border-radius: 8px; /* Rounded corners */
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1); /* Shadow effect */
            animation: slide-in 0.5s ease-out; /* Animation for sliding effect */
        }

        @keyframes slide-in {
            from {
                transform: translateY(-20px);
                opacity: 0;
            }
            to {
                transform: translateY(0);
                opacity: 1;
            }
        }
        
        .text-center {
            text-align: center; /* Center align text */
        }

        .btn-group {
            display: flex;
            justify-content: center; /* Center buttons horizontally */
            gap: 10px; /* Space between buttons */
        }
    </style>
</head>
<body>
<div class="container">
    <h2 class="text-center">Delete Quiz Data for Employee ID: <?php echo htmlspecialchars($employee['employeeid']); ?></h2>
    <p class="text-center">Are you sure you want to delete the quiz data for this employee? This action cannot be undone.</p>
    <form method="POST" class="text-center">
        <div class="btn-group">
            <button type="submit" class="btn btn-danger">Delete Quiz Data</button>
            <a href="admin_profile.php" class="btn btn-secondary">Cancel</a>
        </div>
    </form>
</div>
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.bundle.min.js"></script>
</body>
</html>

