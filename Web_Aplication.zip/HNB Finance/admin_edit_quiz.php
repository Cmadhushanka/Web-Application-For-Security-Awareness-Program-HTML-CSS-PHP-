<?php
// Error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Database connection details
$host = 'localhost';  // Replace with your host
$db = 'taprogram1';    // Replace with your database name
$user = 'root';       // Replace with your database username
$pass = '';           // Replace with your database password

// Create PDO connection
try {
    $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8mb4", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    error_log("Database Connection Error: " . $e->getMessage());
    echo "An error occurred while connecting to the database.";
    exit();
}

// Check if employee ID is provided
if (isset($_GET['id'])) {
    $employeeId = $_GET['id'];

    // Fetch marks data based on employee ID
    $stmt = $pdo->prepare("SELECT * FROM marks WHERE employeeid = :id");
    $stmt->bindParam(':id', $employeeId);
    $stmt->execute();
    $employee = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$employee) {
        echo "Employee not found.";
        exit();
    }
} else {
    echo "No employee ID provided.";
    exit();
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $first_attempt_score = $_POST['first_attempt_score'];
    $first_attempt_status = $_POST['first_attempt_status'];
    $last_attempt_score = $_POST['last_attempt_score'];
    $last_attempt_status = $_POST['last_attempt_status'];

    // Update quiz data in the database
    $stmt = $pdo->prepare("UPDATE marks 
        SET first_attempt_score = :first_attempt_score, 
            first_attempt_status = :first_attempt_status, 
            last_attempt_score = :last_attempt_score, 
            last_attempt_status = :last_attempt_status 
        WHERE employeeid = :id");
    
    $stmt->bindParam(':first_attempt_score', $first_attempt_score);
    $stmt->bindParam(':first_attempt_status', $first_attempt_status);
    $stmt->bindParam(':last_attempt_score', $last_attempt_score);
    $stmt->bindParam(':last_attempt_status', $last_attempt_status);
    $stmt->bindParam(':id', $employeeId); // Correct binding here

    if ($stmt->execute()) {
        header("Location: admin_profile.php"); // Redirect back to dashboard
        exit();
    } else {
        echo "Failed to update quiz data.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Quiz for Employee</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <style>
        body {
            background-color: #e9ecef;
        }
        .container {
            margin-top: 50px;
            max-width: 600px; /* Set a max width for the container */
            padding: 30px; /* Add padding for inner spacing */
            background: white; /* Set a background color */
            border-radius: 8px; /* Rounded corners */
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1); /* Shadow effect */
            animation: slide-in 0.5s ease-out; /* Animation for sliding effect */
        }

        @keyframes slide-in {
            from {
                transform: translateY(-20px);
                opacity: 0;
            }
            to {
                transform: translateY(0);
                opacity: 1;
            }
        }
        
        .text-center {
            text-align: center; /* Center align text */
        }

        .btn-group {
            display: flex;
            justify-content: center; /* Center buttons horizontally */
            gap: 10px; /* Space between buttons */
        }
    </style>
</head>
<body>
<div class="container">
    <h2 class="text-center">Edit Quiz Data for Employee ID: <?php echo htmlspecialchars($employee['employeeid']); ?></h2>
    <form method="POST">
        <div class="form-group">
            <label for="first_attempt_score">First Attempt Score</label>
            <input type="number" class="form-control" name="first_attempt_score" 
                   value="<?php echo htmlspecialchars($employee['first_attempt_score']); ?>" required>
        </div>
        <div class="form-group">
            <label for="first_attempt_status">First Attempt Status</label>
            <select class="form-control" name="first_attempt_status" required>
                <option value="Beginner" <?php if ($employee['first_attempt_status'] == 'Beginner') echo 'selected'; ?>>Beginner</option>
                <option value="Intermediate" <?php if ($employee['first_attempt_status'] == 'Intermediate') echo 'selected'; ?>>Intermediate</option>
                <option value="Expert" <?php if ($employee['first_attempt_status'] == 'Expert') echo 'selected'; ?>>Expert</option>
            </select>
        </div>
        <div class="form-group">
            <label for="last_attempt_score">Last Attempt Score</label>
            <input type="number" class="form-control" name="last_attempt_score" 
                   value="<?php echo htmlspecialchars($employee['last_attempt_score']); ?>" required>
        </div>
        <div class="form-group">
            <label for="last_attempt_status">Last Attempt Status</label>
            <select class="form-control" name="last_attempt_status" required>
                <option value="Beginner" <?php if ($employee['last_attempt_status'] == 'Beginner') echo 'selected'; ?>>Beginner</option>
                <option value="Intermediate" <?php if ($employee['last_attempt_status'] == 'Intermediate') echo 'selected'; ?>>Intermediate</option>
                <option value="Expert" <?php if ($employee['last_attempt_status'] == 'Expert') echo 'selected'; ?>>Expert</option>
            </select>
        </div>
        <div class="btn-group">
            <button type="submit" class="btn btn-primary">Update Quiz Data</button>
            <a href="admin_profile.php" class="btn btn-secondary">Cancel</a>
        </div>
    </form>
</div>
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.bundle.min.js"></script>
</body>
</html>
